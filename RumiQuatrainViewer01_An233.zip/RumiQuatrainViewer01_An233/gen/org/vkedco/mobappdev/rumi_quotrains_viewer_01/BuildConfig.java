/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.mobappdev.rumi_quotrains_viewer_01;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
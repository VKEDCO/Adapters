package org.vkedco.mobappdev.rumi_quotrains_viewer_01;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.EditText;

/*
 ************************************************** 
 * 
 * RumiQuatrainViewer01 is an application that uses a 
 * ListActivity to display the English translations of the 
 * following quatrains by Jalaluddin Rumi: 12, 77, 116, 
 * 494, and 549. The translations are taken from "Open Secret: 
 * Versions of Rumi" by John Moyne and Coleman Barks. The 
 * app has two activities: QuatrainSelector (the main activity) and 
 * QuatrainDisplayer QuatrainSelector uses an ArrayAdapter 
 * to bind an array of quatrain numbers to a ListView and 
 * starts QuatrainDisplayer via an explicit intent.
 * 
 * * Bugs to vladimir dot kulyukin at gmail dot com
 **************************************************
 */

public class QuatrainDisplayer extends Activity {
	
	EditText mEdTxtQuatrain = null; // multi-line text where quatrain is displayed
	Resources mRes = null;
	String[] mQuatrainNumbers = null; // String of quatrain numbers
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.quatrain_displayer_layout01);
		mRes = getResources();
		mQuatrainNumbers = mRes.getStringArray(R.array.quatrain_numbers);
		mEdTxtQuatrain = (EditText) this.findViewById(R.id.ed_txt_quatrain);
		
		Intent i = this.getIntent();

		if ( i.hasExtra(mRes.getString(R.string.quatrain_key)) ) {
			
			int qn = i.getIntExtra(mRes.getString(R.string.quatrain_key), 0);
			String[] quatrain_lines = null;
			switch ( qn ) {
			case 0: 
				quatrain_lines = mRes.getStringArray(R.array.q12);
				break;
			case 1:
				quatrain_lines = mRes.getStringArray(R.array.q77);
				break;
			case 2:
				quatrain_lines = mRes.getStringArray(R.array.q116);
				break;
			case 3:
				quatrain_lines = mRes.getStringArray(R.array.q494);
				break;
			case 4:
				quatrain_lines = mRes.getStringArray(R.array.q549);
				break;
			}
			
			mEdTxtQuatrain.append(this.mQuatrainNumbers[qn]);
			mEdTxtQuatrain.append("\n");
			mEdTxtQuatrain.append("\n");
			for (String line: quatrain_lines ) {
				this.mEdTxtQuatrain.append(line + "\n");
			}
			
			mEdTxtQuatrain.append("\n");
			mEdTxtQuatrain.append("\n");
			mEdTxtQuatrain.append(mRes.getString(R.string.rumi_book_title) + "\n");
			mEdTxtQuatrain.append(mRes.getString(R.string.persian_translation) + "\n");
			mEdTxtQuatrain.append(mRes.getString(R.string.translators) + "\n");
			
			mEdTxtQuatrain.setEnabled(false);
		}
	}
}

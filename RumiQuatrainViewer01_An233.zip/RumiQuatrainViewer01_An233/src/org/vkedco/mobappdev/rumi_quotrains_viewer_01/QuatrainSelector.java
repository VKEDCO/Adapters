package org.vkedco.mobappdev.rumi_quotrains_viewer_01;

import android.os.Bundle;
import android.app.ListActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;

/*
 ************************************************** 
 * 
 * RumiQuatrainViewer01 is an application that uses a 
 * ListActivity to display the English translations of the 
 * following quatrains by Jalaluddin Rumi: 12, 77, 116, 
 * 494, and 549. The translations are taken from "Open Secret: 
 * Versions of Rumi" by John Moyne and Coleman Barks. The 
 * app has two activities: QuatrainSelector (the main activity)
 * and QuatrainDisplayer QuatrainSelector uses an ArrayAdapter 
 * to bind an array of quatrain numbers to a ListView and 
 * starts QuatrainDisplayer via an explicit intent.
 * 
 * Bugs to vladimir dot kulyukin at gmail dot com
 **************************************************
 */

public class QuatrainSelector extends ListActivity
	implements OnItemClickListener
{

	Resources mRes = null;
	String[] mQuatrainNumbers = null;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_quatrain_selector_layout);
        mRes = getResources();
        mQuatrainNumbers = mRes.getStringArray(R.array.quatrain_numbers);
        
        // 1. Get the list view of the current activity
        ListView lv = this.getListView();
        lv.setBackgroundColor(Color.WHITE);
        
        // 2. Create an adapter
        ArrayAdapter<String> adptr = 
        	new ArrayAdapter<String>(this, 
    			android.R.layout.simple_list_item_1, 
    			this.mQuatrainNumbers);
        // 3. Bind the adapter to the list view
        lv.setAdapter(adptr);
        // 4. Enable word completion
        lv.setTextFilterEnabled(true);
        // 5. set this class as the implementation of
        // the OnItemClickListener interface
        lv.setOnItemClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_quatrain_selector_layout, menu);
        return true;
    }
    
    /*
     * parent is a ListView (this is the container)
     * view is a TextView (this is the child view)
     * position is the position of the child view inside the parent container
     * id is the id of the TextView
     */
	@Override
	public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
		
		Intent i = new Intent(this, QuatrainDisplayer.class);
		i.putExtra(mRes.getString(R.string.quatrain_key), pos);
		startActivity(i);
	}
}

/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.android.listviewarrayadapter4;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}